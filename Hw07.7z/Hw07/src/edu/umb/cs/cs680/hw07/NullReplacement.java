/**
 * 
 */
package edu.umb.cs.cs680.hw07;

import java.util.LinkedHashMap;

/**
 * @author avinashreddy
 *
 */
public class NullReplacement implements CacheReplacementPolicy {
	@Override
	public void replace(LinkedHashMap<String, String> hashMap, String file) {
		// TODO Auto-generated method stub
		
	}
}
