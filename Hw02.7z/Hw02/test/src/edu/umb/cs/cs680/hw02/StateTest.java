/**
 * 
 */
package edu.umb.cs.cs680.hw02;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author avinashreddy
 *
 */
public class StateTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
